<footer class="footer">
    <div class="container-fluid">

        <div class="copyright m-auto">
            {{__('2019, made with')}} <i class="fa fa-heart heart text-danger"></i> by <a href="http://www.aisent.net/">Aisent</a>
        </div>
    </div>
</footer>
